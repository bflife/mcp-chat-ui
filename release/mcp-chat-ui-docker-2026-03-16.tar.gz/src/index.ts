import { log } from "./server/log";
import dotenv from "dotenv";
dotenv.config();

import express from "express";
import { createServer } from "http";
import bodyParser from "body-parser";

import { setupMcpServer } from "./server/mcp";
import { setupWsServer } from "./server/ws_server";
import authGoogleRouter from "./server/auth_google";

import path from "path";
import { localHtmlPageRenderer } from "./server/local_html_server";

const app = express();

app.use(express.json());
app.use(authGoogleRouter);

app.use(bodyParser.urlencoded({ extended: true }));
app.post("/webserver", localHtmlPageRenderer);
app.get("/app-config.js", (_req, res) => {
  res.type("application/javascript").send(`window.__APP_CONFIG__ = {
    GOOGLE_CLIENT_ID: ${JSON.stringify(process.env.GOOGLE_CLIENT_ID || "")},
    LOGIN_API_URL: ${JSON.stringify(process.env.LOGIN_API_URL || "")},
    LOGIN_ENABLED: ${JSON.stringify(process.env.LOGIN_ENABLED === "true")},
    LLM_PROVIDER: ${JSON.stringify(process.env.LLM_PROVIDER || "ollama")},
    OLLAMA_BASE_URL: ${JSON.stringify(process.env.OLLAMA_BASE_URL || "http://127.0.0.1:11434/v1")},
    DEFAULT_MODEL: ${JSON.stringify(process.env.DEFAULT_MODEL || "ollama/llama3.1")}
  };`);
});

app.use("/", express.static(path.join(__dirname, "../client/dist")));

const setupServer = async () => {
  log("Setting up MCP Stateless Streamable HTTP Server...");
  setupMcpServer(app);
};

const PORT = 3000;
const httpServer = createServer(app);

setupServer()
  .then(() => {
    const wss = setupWsServer(httpServer);

    const fareWell = () => {
      console.log("Received SIGINT/SIGTERM. Shutting down gracefully...");
      setTimeout(() => {
        console.error("Server shutdown timed out. Forcing exit.");
        process.exit(1);
      }, 2000);
      wss.close(() => {
        console.log("WebSocket server closed.");
        httpServer.close(() => {
          console.log("HTTP server closed. Exiting process.");
          process.exit(0);
        });
      });
    };

    process.on("SIGINT", fareWell);
    process.on("SIGTERM", fareWell);

    httpServer.listen(PORT, (error?: any) => {
      if (error) {
        console.error("Failed to start server:", error);
        process.exit(1);
      }
      console.log(
        `MCP Stateless Streamable HTTP/WebSocket Server listening on port ${PORT}`
      );
    });
  })
  .catch((error) => {
    console.error("Failed to set up the server:", error);
    process.exit(1);
  });
